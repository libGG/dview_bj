//created by lib
using System;
using System.Collections.Generic;
using System.Text;

namespace DView.SXEQJB.TempleteMgr
{
    /// <summary>
    /// ģ�嶨������
    /// </summary>
    public enum CustomStyle
    {
        /// <summary>
        /// �½�
        /// </summary>
        NewTemplete,
        /// <summary>
        /// �޸�
        /// </summary>
        ModifyTemplete
    }
}
